/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ["http://192.168.43.220:3500","https://abstore.zaahirahtravels.com"],
      },
};

export default nextConfig;
