import DiagnosticTableResults from '@/components/tables/DiagnosticTableResults'
import React from 'react'

const Diagnostic = () => {
  return (
    <div><DiagnosticTableResults/></div>
  )
}

export default Diagnostic