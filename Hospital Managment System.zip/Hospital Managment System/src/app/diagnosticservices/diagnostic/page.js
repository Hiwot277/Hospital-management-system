import DiagonsticTable from '@/components/tables/DiagnosticTable'
import React from 'react'

const Diagnostic = () => {
  return (
    <div><DiagonsticTable/></div>
  )
}

export default Diagnostic