import AssignedAppointmentTable from '@/components/tables/AssignendAppointmentTable'
import React from 'react'

const Appointment = () => {
  return (
    <div>
      <AssignedAppointmentTable/>
    </div>
  )
}

export default Appointment