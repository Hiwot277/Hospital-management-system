import PhPrescriptionTable from '@/components/tables/PhPrescriptionTable'
import React from 'react'

const Prescription = () => {
  return (
    <div><PhPrescriptionTable/></div>
  )
}

export default Prescription