import PhAssignedPatientTable from '@/components/tables/PhAssignedPatientTable'
import React from 'react'

const Patient = () => {
  return (
    <div>
      <PhAssignedPatientTable/>
    </div>
  )
}

export default Patient