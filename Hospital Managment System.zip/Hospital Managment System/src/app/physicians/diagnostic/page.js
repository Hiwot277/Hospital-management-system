import PhDiagonsticTable from '@/components/tables/PhDiagnosticTable'
import React from 'react'

const Diagnostic = () => {
  return (
    <div><PhDiagonsticTable/></div>
  )
}

export default Diagnostic