import React from 'react'

const Log = () => {
  return (
    <div>Log</div>
  )
}

export default Log