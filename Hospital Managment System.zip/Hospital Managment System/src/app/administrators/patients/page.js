'use client';
import AdminPatientTable from '@/components/tables/AdminPatientTable';
import React from 'react';

const Patient = () => {
  return (
      <AdminPatientTable />
  );
};

export default Patient;
