import PaymentRequestTable from '@/components/tables/PaymentRequestTable'
import React from 'react'

const Requests = () => {
  return (
    <div><PaymentRequestTable/></div>
  )
}

export default Requests