import AppointmentTable from '@/components/tables/AppointmentTable'
import React from 'react'

const Appointment = () => {
  return (
    <div>
      <AppointmentTable />
    </div>
  )
}

export default Appointment