import AssignedPatientTable from '@/components/tables/AssignedPatientTable'
import React from 'react'

const Assigned = () => {
  return (
    <div><AssignedPatientTable/></div>
  )
}

export default Assigned