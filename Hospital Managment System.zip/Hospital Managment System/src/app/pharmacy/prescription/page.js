import PrescriptionTable from '@/components/tables/PrescriptionTable'
import React from 'react'

const Prescription = () => {
  return (
    <div><PrescriptionTable/></div>
  )
}

export default Prescription