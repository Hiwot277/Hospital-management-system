import React from 'react'

const Drugs = () => {
  return (
    <div>Drugs</div>
  )
}

export default Drugs